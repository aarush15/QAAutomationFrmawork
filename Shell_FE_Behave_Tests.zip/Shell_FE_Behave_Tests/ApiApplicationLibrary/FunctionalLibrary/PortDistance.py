import json
from Shell_FE_Requests_Core.RequestsBase import RequestsBase
from Shell_FE_Requests_Core.Utilities.LoggingUtilities import LoggingUtilities
from Shell_FE_Requests_Core.Utilities.FileUtilities import FileUtilities


class PortDistance:
    log = LoggingUtilities().logger()
    token = ""
    users_dict = FileUtilities.read_json_file_as_dictionary("UsersApi/PortDistanceData.json")
    allFreightDistanceData = []

    def __init__(self):
        PortDistance.token = self.GetAuthenticationCode()
        PortDistance.allFreightDistanceData = self.GetAllFreightDistanceData()

    def GetAuthenticationCode(self):
        RequestsBase.endpoint_url = PortDistance.users_dict["baseUri"]
        payload = PortDistance.users_dict["payload"]
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'PF=wWxtX47HoFWLoRdLFuXbhE; AWSALB=M8g+mvc48JHpx9SqdP6eiagvSyKcQ7IMs/xxX4qwTzHZaMqUh8464'
                      '/aSGB6ZNvn6i4EE1qXKXAy0Q8qZHcgKFnXNsXQA9OvvKW8PXOJSaoRYiyLpUtruWZtlXbd1; '
                      'AWSALBCORS=M8g+mvc48JHpx9SqdP6eiagvSyKcQ7IMs/xxX4qwTzHZaMqUh8464'
                      '/aSGB6ZNvn6i4EE1qXKXAy0Q8qZHcgKFnXNsXQA9OvvKW8PXOJSaoRYiyLpUtruWZtlXbd1; '
                      'PF=wWxtX47HoFWLoRdLFuXbhE; '
                      'AWSALB=0ul1YVecU3o6gAQ2rRelfnAMvIpcJ2oLfg1LPr4hBlLsgmtazOwBo4LD6APA0kDn1hxYM8MtF7I2kNaJydstht4uQpwR1sBCmeEphBKaSgv74kLHDbIVpZMuQnM2; AWSALBCORS=0ul1YVecU3o6gAQ2rRelfnAMvIpcJ2oLfg1LPr4hBlLsgmtazOwBo4LD6APA0kDn1hxYM8MtF7I2kNaJydstht4uQpwR1sBCmeEphBKaSgv74kLHDbIVpZMuQnM2 '
        }
        RequestsBase.post_request(body_data=payload, headers=headers)
        PortDistance.log.info("The status code is: " + str(RequestsBase.response.status_code))
        PortDistance.log.info("The headers passed as part of the request is: "
                              + str(RequestsBase.response.request.headers))
        dict_value = RequestsBase.response_body_as_dictionary()
        return dict_value["access_token"]

    def GetFreightDistanceBetweenTwoPoints(self, load_port, discharge_port, system_name, restriction_type, refresh,
                                           token):
        RequestsBase.endpoint_url = PortDistance.users_dict["functionBaseUri"] + "FetchFreightDistance"
        payload: str = json.dumps([
            {
                "LoadPort": load_port,
                "LoadPort": load_port,
                "DischargePort": discharge_port,
                "SystemName": system_name,
                "RestrictionType": restriction_type,
                "Refresh": refresh
            }
        ])
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
        RequestsBase.post_request(body_data=payload, headers=headers)
        PortDistance.log.info("The status code is: " + str(RequestsBase.response.status_code))
        PortDistance.log.info("The headers passed as part of the request is: "
                              + str(RequestsBase.response.request.headers))

    @staticmethod
    def GetAllFreightDistanceData():
        RequestsBase.endpoint_url = PortDistance.users_dict["FetchAllFreightDistanceUri"]
        RequestsBase.get_request()
        allFreightDistanceData = RequestsBase.response_body_as_dictionary()
        return allFreightDistanceData

