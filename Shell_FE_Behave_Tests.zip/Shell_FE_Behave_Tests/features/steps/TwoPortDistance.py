import datetime
from dateutil import parser
from Shell_FE_Requests_Core.RequestsBase import RequestsBase
from Shell_FE_Requests_Core.Utilities.AssertionUtilities import AssertionUtilities
from behave import When, Then
from Shell_FE_Behave_Tests.ApiApplicationLibrary.FunctionalLibrary.PortDistance import PortDistance


# region Scenario: Get OAuth token
@When('user sends a GET request to retrieve OAuth')
def step_impl(context):
    context.feature.PortDistance = PortDistance()


@Then(u'user validates if the response status is {expected_code} as response')
def step_impl(context, expected_code):
    AssertionUtilities.assert_equals(expected_code, str(RequestsBase.response_status_code()))


@Then(u'user verifies if Oauth token generated from response body')
def step_impl(context):
    AssertionUtilities.assert_if_true(PortDistance.token != "null")


# endregion


@When('User sends a  {load_port} and {discharge_port} and {system_name} and {restriction_type} and {refresh}')
def step_impl(context, load_port, discharge_port, system_name, restriction_type, refresh):
    GetFreightDistanceBetweenTwoPoints(context, load_port, discharge_port, system_name, restriction_type, refresh)


def GetFreightDistanceBetweenTwoPoints(context, load_port, discharge_port, system_name, restriction_type, refresh):
    tokenvalue = PortDistance.token
    context.feature.PortDistance.GetFreightDistanceBetweenTwoPoints(load_port, discharge_port, system_name,
                                                                    restriction_type, refresh,
                                                                    tokenvalue)
    context.feature.PortDistance.load_port = load_port
    context.feature.PortDistance.discharge_port = discharge_port
    context.feature.PortDistance.system_name = system_name
    context.feature.PortDistance.restriction_type = restriction_type


@When(u'User Sends a Get request to get all FreightDistance details')
def step_impl(context):
    AssertionUtilities.assert_not_none(PortDistance.allFreightDistanceData)


@Then(u'user verifies if distance generated from response body')
def step_impl(context):
    dict_value = RequestsBase.response_body_as_dictionary()
    if len(dict_value) == 0:
        AssertionUtilities.assert_if_true(False)
    context.feature.PortDistance.distance_value = dict_value[0]["distance"]


@Then(u'user verifies if timestamp generated from response body should match to the timestamp')
def step_impl(context):
    load_port_input = context.feature.PortDistance.load_port
    discharge_load_input = context.feature.PortDistance.discharge_port
    restriction_type_input = context.feature.PortDistance.restriction_type
    date_value_fromDB=datetime.datetime
    for value in PortDistance.allFreightDistanceData:
        load_port_db = value["from"]
        discharge_load_db = value["to"]
        restriction_type_db = value["restrictionType"]
        if (load_port_input == load_port_db
                and discharge_load_input == discharge_load_db
                and restriction_type_input == restriction_type_db):
            date_value_fromDB = value["timeStamp"]
            break
    date_object = parser.parse(date_value_fromDB)
    AssertionUtilities.assert_if_true(type(date_object) is datetime.datetime)

@Then(u'user verifies if distance generated from response body matches with distance retrieved from DB')
def step_impl(context):
    distance_value_from_api = context.feature.PortDistance.distance_value
    distance_value_fromDB = GetDistanceData(context)
    if distance_value_fromDB == "":
        AssertionUtilities.assert_if_true(False)
    AssertionUtilities.assert_equals(distance_value_from_api, distance_value_fromDB)


@Then(u'User verifies no data(NONE) should be created from response body')
def step_impl(context):
    data = GetDistanceData(context)
    AssertionUtilities.assert_if_true(data == 0.0)


@When(u'User sends invalid token with a valid {load_port} and {discharge_port} and {system_name} and {'
      u'restriction_type} and {refresh}')
def step_impl(context, load_port, discharge_port, system_name, restriction_type, refresh):
    tokenvalue = PortDistance.token + "asd"
    context.feature.PortDistance.GetFreightDistanceBetweenTwoPoints(load_port, discharge_port, system_name,
                                                                    restriction_type, refresh,
                                                                    tokenvalue)


@When('User sends same {load_port} and {discharge_port} with proper {system_name} and {restriction_type} and {refresh}')
def step_impl(context, load_port, discharge_port, system_name, restriction_type, refresh):
    GetFreightDistanceBetweenTwoPoints(context, load_port, discharge_port, system_name, restriction_type, refresh)


@Then('User verifies if discharge_port value is equal to VIA  attribute value from DB')
def step_impl(context):
    load_port_input = context.feature.PortDistance.load_port
    discharge_load_input = context.feature.PortDistance.discharge_port
    restriction_type_input = context.feature.PortDistance.restriction_type
    via_value_fromDB = ""
    for value in PortDistance.allFreightDistanceData:
        load_port_db = value["from"]
        discharge_load_db = value["to"]
        restriction_type_db = value["restrictionType"]
        if (load_port_input == load_port_db
                and discharge_load_input == discharge_load_db
                and restriction_type_input == restriction_type_db):
            via_value_fromDB = value["via"]
            break

    AssertionUtilities.assert_if_true(via_value_fromDB == discharge_load_input)


def GetDistanceData(context: object) -> object:
    load_port_input = context.feature.PortDistance.load_port
    discharge_load_input = context.feature.PortDistance.discharge_port
    restriction_type_input = context.feature.PortDistance.restriction_type
    distance_value_fromDB = ""
    for value in PortDistance.allFreightDistanceData:
        load_port_db = value["from"]
        discharge_load_db = value["to"]
        restriction_type_db = value["restrictionType"]
        if (load_port_input == load_port_db
                and discharge_load_input == discharge_load_db
                and restriction_type_input == restriction_type_db):
            distance_value_fromDB = value["distance"]
            break
    return distance_value_fromDB
